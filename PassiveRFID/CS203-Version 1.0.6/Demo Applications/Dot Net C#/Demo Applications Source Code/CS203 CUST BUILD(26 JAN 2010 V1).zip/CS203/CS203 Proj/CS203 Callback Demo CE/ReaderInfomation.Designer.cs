namespace CS203_CALLBACK_API_DEMO_CE
{
    partial class ReaderInfomation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb_libver = new System.Windows.Forms.Label();
            this.tb_dirVer = new System.Windows.Forms.Label();
            this.tb_cslVer = new System.Windows.Forms.Label();
            this.tb_fwVer = new System.Windows.Forms.Label();
            this.tb_hwVer = new System.Windows.Forms.Label();
            this.tb_pcbaCode = new System.Windows.Forms.Label();
            this.tb_manufactureDate = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.LinkLabel();
            this.tb_sn = new System.Windows.Forms.Label();
            this.tb_deviceName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 20);
            this.label1.Text = "Reader Information";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Blue;
            this.panel1.Location = new System.Drawing.Point(-3, 123);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(320, 1);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular);
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(0, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(314, 20);
            this.label2.Text = "Version Information";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Blue;
            this.panel2.Location = new System.Drawing.Point(0, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(320, 1);
            // 
            // tb_libver
            // 
            this.tb_libver.Location = new System.Drawing.Point(153, 129);
            this.tb_libver.Name = "tb_libver";
            this.tb_libver.Size = new System.Drawing.Size(160, 20);
            this.tb_libver.Text = "0.0.0";
            // 
            // tb_dirVer
            // 
            this.tb_dirVer.Location = new System.Drawing.Point(153, 149);
            this.tb_dirVer.Name = "tb_dirVer";
            this.tb_dirVer.Size = new System.Drawing.Size(160, 20);
            this.tb_dirVer.Text = "0.0.0";
            // 
            // tb_cslVer
            // 
            this.tb_cslVer.Location = new System.Drawing.Point(153, 169);
            this.tb_cslVer.Name = "tb_cslVer";
            this.tb_cslVer.Size = new System.Drawing.Size(160, 20);
            this.tb_cslVer.Text = "0.0.0";
            // 
            // tb_fwVer
            // 
            this.tb_fwVer.Location = new System.Drawing.Point(153, 189);
            this.tb_fwVer.Name = "tb_fwVer";
            this.tb_fwVer.Size = new System.Drawing.Size(160, 20);
            this.tb_fwVer.Text = "0.0.0";
            // 
            // tb_hwVer
            // 
            this.tb_hwVer.Location = new System.Drawing.Point(153, 209);
            this.tb_hwVer.Name = "tb_hwVer";
            this.tb_hwVer.Size = new System.Drawing.Size(160, 20);
            this.tb_hwVer.Text = "0.0.0";
            // 
            // tb_pcbaCode
            // 
            this.tb_pcbaCode.Location = new System.Drawing.Point(153, 44);
            this.tb_pcbaCode.Name = "tb_pcbaCode";
            this.tb_pcbaCode.Size = new System.Drawing.Size(160, 20);
            this.tb_pcbaCode.Text = "0.0.0";
            // 
            // tb_manufactureDate
            // 
            this.tb_manufactureDate.Location = new System.Drawing.Point(153, 64);
            this.tb_manufactureDate.Name = "tb_manufactureDate";
            this.tb_manufactureDate.Size = new System.Drawing.Size(160, 20);
            this.tb_manufactureDate.Text = "0.0.0";
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(275, 0);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(42, 16);
            this.close.TabIndex = 11;
            this.close.Text = "Close";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // tb_sn
            // 
            this.tb_sn.Location = new System.Drawing.Point(153, 84);
            this.tb_sn.Name = "tb_sn";
            this.tb_sn.Size = new System.Drawing.Size(160, 20);
            this.tb_sn.Text = "0.0.0";
            // 
            // tb_deviceName
            // 
            this.tb_deviceName.Location = new System.Drawing.Point(153, 24);
            this.tb_deviceName.Name = "tb_deviceName";
            this.tb_deviceName.Size = new System.Drawing.Size(160, 20);
            this.tb_deviceName.Text = "0.0.0";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(17, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 20);
            this.label3.Text = "PCB Assembly Code :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(17, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 20);
            this.label4.Text = "Device Name :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(17, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 20);
            this.label5.Text = "Manufacture Date :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(17, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 20);
            this.label6.Text = "Serial Number :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(3, 129);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(148, 20);
            this.label7.Text = "RFID Library Version :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(17, 209);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(134, 20);
            this.label8.Text = "Hardware Revision :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(3, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(148, 20);
            this.label9.Text = "USB Driver Version :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(17, 169);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(134, 20);
            this.label10.Text = "CSLibrary Version :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(17, 189);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(134, 20);
            this.label11.Text = "Firmware Version :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ReaderInfomation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(320, 240);
            this.ControlBox = false;
            this.Controls.Add(this.close);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.tb_fwVer);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tb_cslVer);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tb_dirVer);
            this.Controls.Add(this.tb_hwVer);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tb_sn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_manufactureDate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_deviceName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tb_pcbaCode);
            this.Controls.Add(this.tb_libver);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "ReaderInfomation";
            this.Text = "ReaderInfomation";
            this.Load += new System.EventHandler(this.ReaderInfomation_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.ReaderInfomation_Closing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label tb_libver;
        private System.Windows.Forms.Label tb_dirVer;
        private System.Windows.Forms.Label tb_cslVer;
        private System.Windows.Forms.Label tb_fwVer;
        private System.Windows.Forms.Label tb_hwVer;
        private System.Windows.Forms.Label tb_pcbaCode;
        private System.Windows.Forms.Label tb_manufactureDate;
        private System.Windows.Forms.LinkLabel close;
        private System.Windows.Forms.Label tb_sn;
        private System.Windows.Forms.Label tb_deviceName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}