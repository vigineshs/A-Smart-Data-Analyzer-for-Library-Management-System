using System;
using System.Collections.Generic;
using System.Text;

namespace CS203DEMO
{
    class LocalSettings
    {
        public static string ServerIP = "";
        public static string ServerName = "SQLEXPRESS";
        public static string DBName = "";
        public static string UserID = "";
        public static string Password = "";
    }
}
